package itesm.mx.a01191342_examenvinculacion_ahorroenergia;

/**
 * Created by Jibril on 10/28/17.
 */

public interface OnElectroSelectedListener {
    public void onElectroSelected(int position);
}
