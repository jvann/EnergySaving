package itesm.mx.a01191342_examenvinculacion_ahorroenergia;

/**
 * Created by Jibril on 10/30/17.
 */

public interface OnItemClickedListener {
    public void onElectroSelected(int position);
    public void onEventSelected(int position);
    public void onReportClick(int position);
}
